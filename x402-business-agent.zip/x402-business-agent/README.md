# x402 Business Agent

Payment-gated business document analysis API using x402 on Base.

## Endpoint

- GET /health — public health check
- POST /analyze — requires an x402 payment of $0.50 USDC

## Configuration

Set `PAY_TO` to the public EVM address that should receive payments. Never put a seed phrase, private key, password, or 2FA code in the repository.

Network: Base Mainnet (`eip155:8453`).

## Deploy on Render

The repository includes `render.yaml`. Create a Blueprint from the repository, set `PAY_TO` to the intended public wallet address, and deploy.

## Current MVP

The API is payment-enabled and returns structured baseline findings. It is not yet connected to an external LLM. The next production step is to add an LLM through a server-side environment secret.
